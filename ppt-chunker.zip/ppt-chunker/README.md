# PPT Chunk Pipeline

Convert PowerPoint presentations into chunked video players for GitHub Pages.
Each slide becomes a looping video segment, with transitions played between them.
Navigate with arrow keys like a slide deck, but with full video fidelity.

## How It Works

```
PPTX ──analyze──> timing_config.json ──(edit)──> chunk ──> output/
  │                                                          ├── chunks/
  │                                                          │   ├── slide_01.mp4
  └──(PowerPoint export)──> presentation.mp4 ───────────────>│   ├── trans_02.mp4
                                                             │   ├── slide_02.mp4
                                                             │   └── ...
                                                             ├── manifest.json
                                                             └── index.html
```

**Architecture:** The MP4 is split into individual slide and transition chunks.
The web player loads `manifest.json`, plays each slide chunk on loop, and when
the user presses the right arrow key, it plays the transition chunk and then
loops the next slide. Two `<video>` elements are double-buffered for gapless
playback.

---

## Requirements

- **Python 3.8+**
- **python-pptx**: `pip install python-pptx lxml`
- **ffmpeg**: Must be on your PATH
  - Windows: `winget install ffmpeg` or download from https://ffmpeg.org
  - macOS: `brew install ffmpeg`
  - Linux: `sudo apt install ffmpeg`

---

## Step-by-Step

### 1. Analyze the PPTX

```bash
python chunk_presentation.py analyze "path/to/your/presentation.pptx"
```

This reads the PPTX XML and produces `output/timing_config.json`:

```json
{
  "segments": [
    {
      "slide_number": 1,
      "label": "Title Slide",
      "slide_duration_s": 5.0,
      "transition_duration_s": 0.0,
      "transition_type": "none"
    },
    {
      "slide_number": 2,
      "label": "Introduction",
      "slide_duration_s": 5.0,
      "transition_duration_s": 1.0,
      "transition_type": "fade"
    }
  ]
}
```

### 2. Edit Timing Config (optional but recommended)

Open `output/timing_config.json` and adjust:

- **`slide_duration_s`**: How long the static slide is shown in the MP4 export.
  This becomes the looping chunk duration.
- **`transition_duration_s`**: The transition animation duration.
- **`label`**: The chapter name shown in the player HUD.

**Important:** These durations must match what PowerPoint actually exports.
If you set 5s per slide and 1s transitions in PowerPoint, they should match here.

### 3. Export MP4 from PowerPoint

In PowerPoint:

1. **Set slide timings**: Transitions tab, set "After" to match your config
   (e.g., 5.00 seconds per slide)
2. **Set transition durations**: Transitions tab, set Duration
   (e.g., 01.00 for 1 second)
3. **File > Export > Create a Video**
4. Resolution: Full HD (1080p) recommended
5. Select: "Use Recorded Timings and Narrations"
6. Save as `presentation.mp4`

### 4. Chunk the MP4

```bash
python chunk_presentation.py chunk presentation.mp4 --config output/timing_config.json
```

This creates:
- `output/chunks/slide_01.mp4`, `slide_02.mp4`, ...
- `output/chunks/trans_02.mp4`, `trans_03.mp4`, ...
- `output/manifest.json`

### 5. Deploy to GitHub Pages

Copy the player and output into your repo:

```
your-repo/
├── presentations/
│   └── my-talk/
│       ├── index.html          # copy from player/index.html
│       ├── manifest.json       # from output/
│       └── chunks/             # from output/chunks/
│           ├── slide_01.mp4
│           ├── trans_02.mp4
│           ├── slide_02.mp4
│           └── ...
```

Enable GitHub Pages in repo Settings > Pages > Source: main branch.

Access at: `https://yourusername.github.io/your-repo/presentations/my-talk/`

---

## Player Controls

| Key         | Action              |
|-------------|---------------------|
| Arrow Right | Next slide          |
| Arrow Left  | Previous slide      |
| Space       | Pause / Resume      |
| F           | Toggle fullscreen   |
| ?           | Toggle help overlay |
| Click       | Next slide          |

---

## File Size Considerations

GitHub Pages has a soft limit of 1GB per repo. For large presentations:

**Option A: Git LFS**
```bash
git lfs install
git lfs track "*.mp4"
git add .gitattributes
git add presentations/
git commit -m "Add presentation chunks"
```

**Option B: External hosting (Cloudflare R2)**
1. Upload chunks/ folder to an R2 bucket
2. Set up a public custom domain
3. Update `index.html` to set `BASE_PATH` to your R2 URL:
   ```js
   const BASE_PATH = "https://assets.yourdomain.com/presentations/my-talk/";
   ```

---

## Adapting for Another Presentation

The pipeline is fully generic. For any new PPTX:

```bash
# 1. Analyze new PPTX
python chunk_presentation.py analyze "New_Presentation.pptx" -o output_new

# 2. Edit output_new/timing_config.json if needed

# 3. Export MP4 from PowerPoint with matching timings

# 4. Chunk
python chunk_presentation.py chunk "New_Presentation.mp4" \
    --config output_new/timing_config.json \
    -o output_new

# 5. Copy output_new/ contents + index.html to a new folder in your repo
```

---

## Troubleshooting

**Chunks don't align with slides:**
The timing_config.json durations must match what PowerPoint actually exported.
PowerPoint sometimes adds small padding. Verify by checking:
```bash
ffprobe -v quiet -print_format json -show_format presentation.mp4
```
Compare the total duration to your config total and adjust as needed.

**Gap/flash between loops:**
The player uses double-buffered `<video>` elements to minimize this.
If you still see gaps, ensure chunks were re-encoded (the script does this by
default with `-g 15` for frequent keyframes).

**Transition chunk plays incorrectly:**
Check that the transition duration in PowerPoint matches the config.
You can preview individual chunks: `ffplay output/chunks/trans_02.mp4`

**Video too large for GitHub:**
Use Git LFS or host chunks externally. See "File Size Considerations" above.

---

## Architecture Notes (for developers)

### manifest.json structure

```json
{
  "title": "Presentation",
  "total_slides": 12,
  "chunks": [
    {
      "type": "slide",
      "file": "chunks/slide_01.mp4",
      "duration": 5.0,
      "slide_number": 1,
      "label": "Title",
      "loop": true
    },
    {
      "type": "transition",
      "file": "chunks/trans_02.mp4",
      "duration": 1.0,
      "slide_from": 1,
      "slide_to": 2
    },
    {
      "type": "slide",
      "file": "chunks/slide_02.mp4",
      "duration": 5.0,
      "slide_number": 2,
      "label": "Introduction",
      "loop": true
    }
  ]
}
```

### Player double-buffer strategy

Two `<video>` elements (`vid-a`, `vid-b`) are stacked via CSS z-index.
The active video loops the current slide. When the user presses right arrow:

1. The standby video (pre-loaded with the transition chunk) is revealed via
   `opacity: 1` and plays once.
2. On the `ended` event, the standby video is hidden again.
3. The roles swap: the standby becomes active and loads the next slide chunk
   with `loop: true`.
4. The now-standby element preloads the next transition.

This eliminates the ~30ms gap that browsers introduce when looping a single
`<video>` element or switching sources.

### Extending the player

The player is a single self-contained HTML file with no dependencies.
To customize:

- **Auto-advance**: Add a timer in the slide playback that calls `goNext()`
  after N seconds.
- **Slide thumbnails**: Export slides as PNGs, add a sidebar/drawer toggled
  with a key.
- **Progress chapters**: Make the tick marks clickable to jump to any slide.
- **Audio narration**: Remove the `-an` flag in `cut_chunk()` and set
  `muted = false` on the video elements.
- **Mobile swipe**: Add touch event listeners for swipe left/right.
