#!/usr/bin/env python3
"""
PPT Chunk Pipeline
==================
Extracts slide/transition timing from a .pptx, chunks an exported .mp4
into individual slide and transition segments, and generates a manifest.json
for the GitHub Pages player.

Usage:
    # Step 1: Analyze PPTX and generate timing config
    python chunk_presentation.py analyze presentation.pptx

    # Step 2: (Optional) Edit timing_config.json to adjust durations

    # Step 3: Chunk the MP4 using the timing config
    python chunk_presentation.py chunk presentation.mp4 --config timing_config.json

    # Step 4: Copy output/ folder to your GitHub Pages repo

Requirements:
    pip install python-pptx
    ffmpeg (must be on PATH)
"""

import argparse
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path
from lxml import etree


# ---------------------------------------------------------------------------
# STEP 1: Analyze PPTX and extract timing
# ---------------------------------------------------------------------------

def analyze_pptx(pptx_path: str, output_dir: str = "output"):
    """
    Parse the .pptx XML to extract:
      - Number of slides
      - advTm (auto-advance time in ms) per slide
      - Transition type and duration per slide

    Produces timing_config.json with editable durations.
    """
    pptx_path = Path(pptx_path)
    if not pptx_path.exists():
        print(f"ERROR: File not found: {pptx_path}")
        sys.exit(1)

    ns = {
        "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
        "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
        "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
        "p14": "http://schemas.microsoft.com/office/powerpoint/2010/main",
    }

    slides_info = []

    with zipfile.ZipFile(pptx_path) as z:
        # Get ordered slide list from presentation.xml
        pres_xml = etree.parse(z.open("ppt/presentation.xml"))
        sld_id_lst = pres_xml.findall(".//p:sldIdLst/p:sldId", ns)

        # Map rId to slide filenames via ppt/_rels/presentation.xml.rels
        rels_xml = etree.parse(z.open("ppt/_rels/presentation.xml.rels"))
        rels_ns = {"r": "http://schemas.openxmlformats.org/package/2006/relationships"}
        rid_map = {}
        for rel in rels_xml.findall(".//r:Relationship", rels_ns):
            # fallback: no namespace
            pass
        # Try without namespace (rels files often have no prefix)
        for rel in rels_xml.getroot():
            rid = rel.get("Id")
            target = rel.get("Target")
            if rid and target:
                rid_map[rid] = target

        # Build ordered slide file list
        slide_files = []
        for sld_id in sld_id_lst:
            r_id = sld_id.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
            if r_id and r_id in rid_map:
                slide_files.append(rid_map[r_id])
            else:
                # Fallback: guess sequentially
                pass

        # If mapping failed, fall back to sequential
        if not slide_files:
            names = [n for n in z.namelist() if n.startswith("ppt/slides/slide") and n.endswith(".xml")]
            # Sort numerically
            import re
            names.sort(key=lambda x: int(re.search(r"slide(\d+)", x).group(1)))
            slide_files = [n.replace("ppt/", "") for n in names]

        print(f"Found {len(slide_files)} slides\n")

        for i, sf in enumerate(slide_files):
            slide_path = f"ppt/{sf}" if not sf.startswith("ppt/") else sf
            try:
                slide_xml = etree.parse(z.open(slide_path))
            except KeyError:
                # Try without ppt/ prefix
                slide_xml = etree.parse(z.open(sf))

            root = slide_xml.getroot()

            # Extract transition info
            transition = root.find(".//p:transition", ns)
            trans_info = {
                "type": "none",
                "duration_ms": 0,
                "advance_after_ms": None,
            }

            if transition is not None:
                # Transition speed/duration
                spd = transition.get("spd")  # slow, med, fast
                dur = transition.get("dur")   # explicit ms (newer format)
                adv_tm = transition.get("advTm")  # auto-advance time in ms
                adv_click = transition.get("advClick", "1")

                # Transition type is the first child element
                for child in transition:
                    tag = etree.QName(child.tag).localname
                    if tag not in ("sndAc", "sndLst"):
                        trans_info["type"] = tag
                        break

                if dur:
                    trans_info["duration_ms"] = int(dur)
                elif spd:
                    speed_map = {"slow": 1000, "med": 750, "fast": 500}
                    trans_info["duration_ms"] = speed_map.get(spd, 750)

                if adv_tm:
                    trans_info["advance_after_ms"] = int(adv_tm)

            # Extract slide title (first text in first title shape)
            title = f"Slide {i + 1}"
            for sp in root.findall(".//p:sp", ns):
                nvSpPr = sp.find(".//p:nvSpPr/p:nvPr/p:ph", ns)
                if nvSpPr is not None and nvSpPr.get("type", "") in ("title", "ctrTitle"):
                    texts = sp.findall(".//a:t", ns)
                    if texts:
                        title = "".join(t.text or "" for t in texts).strip()
                        break

            slides_info.append({
                "slide_number": i + 1,
                "title": title,
                "transition_type": trans_info["type"],
                "transition_duration_ms": trans_info["duration_ms"],
                "advance_after_ms": trans_info["advance_after_ms"],
            })

            print(f"  Slide {i+1}: \"{title}\"")
            print(f"    Transition: {trans_info['type']} ({trans_info['duration_ms']}ms)")
            if trans_info["advance_after_ms"]:
                print(f"    Auto-advance: {trans_info['advance_after_ms']}ms")
            print()

    # Build timing config with editable defaults
    config = build_timing_config(slides_info)

    os.makedirs(output_dir, exist_ok=True)
    config_path = os.path.join(output_dir, "timing_config.json")
    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"Timing config written to: {config_path}")
    print("Edit this file to adjust slide/transition durations before chunking.")
    return config


def build_timing_config(slides_info: list) -> dict:
    """
    Build an editable timing config from parsed slide info.

    The config specifies for each slide:
      - slide_duration_s:      how long the static slide is shown (looped in player)
      - transition_duration_s:  how long the transition animation lasts
      - label:                  chapter name for the player

    The MP4 structure is:
      [trans_1?][slide_1][trans_2][slide_2][trans_3][slide_3]...

    Slide 1 may or may not have a preceding transition.
    """
    DEFAULT_SLIDE_DURATION_S = 5.0
    segments = []

    for info in slides_info:
        # Slide display duration: use advance_after_ms if set, else default
        if info["advance_after_ms"]:
            slide_dur = info["advance_after_ms"] / 1000.0
        else:
            slide_dur = DEFAULT_SLIDE_DURATION_S

        # Transition duration from PPTX
        trans_dur = info["transition_duration_ms"] / 1000.0

        segments.append({
            "slide_number": info["slide_number"],
            "label": info["title"],
            "slide_duration_s": round(slide_dur, 3),
            "transition_duration_s": round(trans_dur, 3),
            "transition_type": info["transition_type"],
        })

    return {
        "_comment": "Edit durations below. slide_duration_s = static slide time. transition_duration_s = transition animation time. The MP4 is structured as: [optional_trans_1][slide_1][trans_2][slide_2]...",
        "default_slide_duration_s": DEFAULT_SLIDE_DURATION_S,
        "segments": segments,
    }


# ---------------------------------------------------------------------------
# STEP 2: Chunk the MP4
# ---------------------------------------------------------------------------

def chunk_mp4(mp4_path: str, config_path: str, output_dir: str = "output"):
    """
    Split an MP4 into individual chunk files based on timing_config.json.

    Produces:
      output/
        chunks/
          slide_01.mp4
          trans_02.mp4
          slide_02.mp4
          trans_03.mp4
          ...
        manifest.json   (for the web player)
    """
    mp4_path = Path(mp4_path)
    if not mp4_path.exists():
        print(f"ERROR: File not found: {mp4_path}")
        sys.exit(1)

    with open(config_path) as f:
        config = json.load(f)

    segments = config["segments"]
    chunks_dir = os.path.join(output_dir, "chunks")
    os.makedirs(chunks_dir, exist_ok=True)

    # Get video duration for validation
    probe = subprocess.run(
        ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", str(mp4_path)],
        capture_output=True, text=True
    )
    video_duration = float(json.loads(probe.stdout)["format"]["duration"])
    print(f"Video duration: {video_duration:.2f}s\n")

    # Calculate expected total duration from config
    total_expected = 0
    for seg in segments:
        total_expected += seg["transition_duration_s"] + seg["slide_duration_s"]
    print(f"Config total:   {total_expected:.2f}s")

    if abs(video_duration - total_expected) > 1.0:
        print(f"\nWARNING: Video duration ({video_duration:.2f}s) differs from config "
              f"total ({total_expected:.2f}s) by {abs(video_duration - total_expected):.2f}s.")
        print("Adjust timing_config.json durations to match your MP4 export.\n")

    # Build cut list
    cursor = 0.0
    manifest_entries = []
    chunk_index = 0

    for seg in segments:
        slide_num = seg["slide_number"]
        trans_dur = seg["transition_duration_s"]
        slide_dur = seg["slide_duration_s"]

        # Transition chunk (skip if no real transition)
        has_transition = trans_dur > 0 and seg.get("transition_type", "none") != "none"
        if has_transition:
            chunk_index += 1
            fname = f"trans_{slide_num:02d}.mp4"
            fpath = os.path.join(chunks_dir, fname)

            cut_chunk(mp4_path, cursor, trans_dur, fpath)
            manifest_entries.append({
                "type": "transition",
                "file": f"chunks/{fname}",
                "duration": round(trans_dur, 3),
                "slide_from": slide_num - 1 if slide_num > 1 else 0,
                "slide_to": slide_num,
            })
            cursor += trans_dur

        # Slide chunk
        chunk_index += 1
        fname = f"slide_{slide_num:02d}.mp4"
        fpath = os.path.join(chunks_dir, fname)

        cut_chunk(mp4_path, cursor, slide_dur, fpath)
        manifest_entries.append({
            "type": "slide",
            "file": f"chunks/{fname}",
            "duration": round(slide_dur, 3),
            "slide_number": slide_num,
            "label": seg["label"],
            "loop": True,
        })
        cursor += slide_dur

    # Write manifest
    manifest = {
        "title": "Presentation",
        "total_slides": len(segments),
        "chunks": manifest_entries,
    }

    manifest_path = os.path.join(output_dir, "manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"\nCreated {chunk_index} chunks in {chunks_dir}/")
    print(f"Manifest written to {manifest_path}")
    print(f"Cursor ended at {cursor:.2f}s (video is {video_duration:.2f}s)")


def cut_chunk(mp4_path: Path, start: float, duration: float, output_path: str):
    """Cut a segment from the MP4 using ffmpeg with re-encoding for precision."""
    print(f"  Cutting: {os.path.basename(output_path)}  "
          f"[{start:.3f}s -- {start + duration:.3f}s]  ({duration:.3f}s)")

    cmd = [
        "ffmpeg", "-y",
        "-ss", f"{start:.3f}",
        "-i", str(mp4_path),
        "-t", f"{duration:.3f}",
        # Re-encode for frame-accurate cuts and seamless looping
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "18",
        "-g", "15",              # keyframe every 15 frames for instant loop rewind
        "-pix_fmt", "yuv420p",
        "-movflags", "+faststart",
        "-c:a", "aac",
        "-b:a", "128k",
        "-an",                    # drop audio (presentation slides)
        output_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"    ffmpeg error: {result.stderr[-300:]}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="PPT Chunk Pipeline: PPTX -> timing config -> MP4 chunks -> web player"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # analyze
    p_analyze = sub.add_parser("analyze", help="Extract timing from PPTX")
    p_analyze.add_argument("pptx", help="Path to .pptx file")
    p_analyze.add_argument("-o", "--output-dir", default="output",
                           help="Output directory (default: output)")

    # chunk
    p_chunk = sub.add_parser("chunk", help="Chunk MP4 based on timing config")
    p_chunk.add_argument("mp4", help="Path to exported .mp4 file")
    p_chunk.add_argument("-c", "--config", default="output/timing_config.json",
                         help="Path to timing_config.json")
    p_chunk.add_argument("-o", "--output-dir", default="output",
                         help="Output directory (default: output)")

    args = parser.parse_args()

    if args.command == "analyze":
        analyze_pptx(args.pptx, args.output_dir)
    elif args.command == "chunk":
        chunk_mp4(args.mp4, args.config, args.output_dir)


if __name__ == "__main__":
    main()
